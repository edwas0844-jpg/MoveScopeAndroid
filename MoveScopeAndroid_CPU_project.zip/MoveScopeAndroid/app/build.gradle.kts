plugins {
    id("com.android.application")
}

android {
    namespace = "com.movescope.chess"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.movescope.chess"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
